import React from "react";
import { FaTachometerAlt, FaUser, FaDownload } from 'react-icons/fa';
import logo from './logo.png';


export default function Sidebar({ isOpen, toggleSidebar }) {
  return (
    <aside className={`bg-stone-800 text-white w-64 h-full p-4 fixed z-20 transform ${isOpen ? 'translate-x-0' : '-translate-x-full'} transition-transform duration-300 ease-in-out border-r-4 border-sky-300`}>
      
      <div className='flex items-center mb-5 border-b-2 border-orange-500 '>
          <img alt="logo" src={logo} className='h-16' />
          <h1 className="text-lg font-bold text-red-600">Epitome <span className='text-white '>Sales</span></h1>
      </div>
      
      <ul>
        <li>
          <a href="/dashboard" className="flex items-center block p-2 hover:bg-stone-600 rounded-md">
            <FaTachometerAlt className="mr-2 text-orange-500" />
             Dashboard
          </a>
        </li>
        <li>
          <a href="/clientform" className="flex items-center block p-2 hover:bg-stone-600 rounded-md">
            <FaUser className="mr-2 text-orange-500" />
            Client Form
          </a>
        </li>
        {/* <li>
          <a href="#" className="flex items-center block p-2 hover:bg-stone-600 rounded-md">
            <FaDownload className="mr-2 text-orange-500" />
            Download Meeting
          </a>
        </li> */}
      </ul>
      {/* Toggle Button 
      <button onClick={toggleSidebar} className="absolute top-5 left-60 pl-2 p-1 focus:outline-none rounded-full bg-stone-800 border-r-4 border-sky-300 w-11">
        <svg className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          {isOpen ? (
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          ) : (
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          )}
        </svg>
      </button>*/}
    </aside>
  );
};
